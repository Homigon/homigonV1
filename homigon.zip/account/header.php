<nav>
    <a href="./" class="logo"><img src="../images/House me 2.png" alt=""></a>
    <div class="nav2" id="nav"></div>
    <ul id="link">
        <img src="../images/close-x.png" alt="" id="closeicon">
        <li><a href="list-a-house">List A House</a></li>
        <!-- <li><a href="../product-listing">Rent</a></li>
        <li><a href="../product-listing">Buy</a></li> -->
        <li class="i" id="account">
            <a href="logout">
                <img src="../images/user.png" alt="" style="height:1.2rem ; padding-right:.3rem;">
                <p> Logout?</p>
            </a>
        </li>
        <li class="i"><a href="../faq">
                <img src="../images/icons8-help-30.png" style="width: 25px;" alt="">
                <p> Help </p>
            </a>
        </li>
    </ul>
    <div class="mediaM">
        <img src="../images/white-menu-icon-4 (1).jpg" alt="" id="menubar">
        <a href="../sign-in"><img src="../images/user.png" alt="" id="acct"></a>
    </div>
</nav>