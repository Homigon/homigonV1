var img = document.getElementById("img");


