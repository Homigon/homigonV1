 if ($(window).width() < 500) {
     $("#sidebarToggle").click();

 }