<?php
session_start();

include 'classes/database.class.php';
include 'classes/admin.class.php';
include 'classes/users.class.php';
include 'classes/items.class.php';

// $admin->createAdmin("Admin", "1234");
// $user->createUser("1234", "Agent", "John", "Doe", "john@gmail.com", "0903278372", "1234", "Agent");
// $item->createItem("1234", "Rent", "Flat", "2 Bathroom Flatfor Rent", "Eneka", "Furnished", "Igwuruta Roundabout", 3, "{amm}", 4, 500000, 2, "No additional information", "[images, images]");
// $user->saveItem("1234", "5678");

// $user->addVerification("1234", "John", "Doe", "Male", "8th Oct 1999", "090276344", "john@gmail.com", "Nigeria", "Rivers", "Bonny", "Igwuruta", "NIN", "8687856566", "[]");

// print_r($admin->getCategories());
// print_r($admin->getTypes());
